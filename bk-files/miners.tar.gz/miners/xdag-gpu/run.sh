#!/bin/bash
./xdag-gpu -G -a y79N35mOkTJGsPocvWCoxrLJPThq+RD2  -t 0 -p xdag.vspool.com:13654   -cl-local-work 768 -cl-global-work 4096
