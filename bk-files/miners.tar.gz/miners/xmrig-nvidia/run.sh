#!/bin/bash

./xmrig-nvidia -o xmr.f2pool.com:13531 -u 48LHRj3T9Jfeq87sikft1ijRzuGjo5w21ALP5gnvPeTkdqGgh2qQo7LXwKpuFDnoEUWhyHZrWsiuxVqHkAikyAuo1t9y5zE.001 -p x -k --api-port=3333 --donate-level=2
